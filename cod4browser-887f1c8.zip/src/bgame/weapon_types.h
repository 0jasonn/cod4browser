#pragma once

#include <cstddef>
#include <cstdint>

// Canonical KisakCOD/IW3 gameplay-facing weapon asset structure. This header
// intentionally keeps renderer, sound implementation, and XAnim runtime
// definitions out of the database loader's include graph.
struct XModel;
struct FxEffectDef;
struct snd_alias_list_t;
struct Material;

enum weapType_t : std::int32_t
{                                       // ...
    WEAPTYPE_BULLET = 0x0,
    WEAPTYPE_GRENADE = 0x1,
    WEAPTYPE_PROJECTILE = 0x2,
    WEAPTYPE_BINOCULARS = 0x3,
    WEAPTYPE_NUM = 0x4,
};

enum weapClass_t : std::int32_t
{                                       // ...
    WEAPCLASS_RIFLE = 0x0,
    WEAPCLASS_MG = 0x1,
    WEAPCLASS_SMG = 0x2,
    WEAPCLASS_SPREAD = 0x3,
    WEAPCLASS_PISTOL = 0x4,
    WEAPCLASS_GRENADE = 0x5,
    WEAPCLASS_ROCKETLAUNCHER = 0x6,
    WEAPCLASS_TURRET = 0x7,
    WEAPCLASS_NON_PLAYER = 0x8,
    WEAPCLASS_ITEM = 0x9,
    WEAPCLASS_NUM = 0xA,
};

enum PenetrateType : std::int32_t
{                                       // ...
    PENETRATE_TYPE_NONE = 0x0,
    PENETRATE_TYPE_SMALL = 0x1,
    PENETRATE_TYPE_MEDIUM = 0x2,
    PENETRATE_TYPE_LARGE = 0x3,
    PENETRATE_TYPE_COUNT = 0x4,
};

enum ImpactType : std::int32_t
{                                       // ...
    IMPACT_TYPE_NONE = 0x0,
    IMPACT_TYPE_BULLET_SMALL = 0x1,
    IMPACT_TYPE_BULLET_LARGE = 0x2,
    IMPACT_TYPE_BULLET_AP = 0x3,
    IMPACT_TYPE_SHOTGUN = 0x4,
    IMPACT_TYPE_GRENADE_BOUNCE = 0x5,
    IMPACT_TYPE_GRENADE_EXPLODE = 0x6,
    IMPACT_TYPE_ROCKET_EXPLODE = 0x7,
    IMPACT_TYPE_PROJECTILE_DUD = 0x8,
    IMPACT_TYPE_COUNT = 0x9,
};

enum weapInventoryType_t : std::int32_t
{                                       // ...
    WEAPINVENTORY_PRIMARY = 0x0,
    WEAPINVENTORY_OFFHAND = 0x1,
    WEAPINVENTORY_ITEM = 0x2,
    WEAPINVENTORY_ALTMODE = 0x3,
    WEAPINVENTORYCOUNT = 0x4,
};

enum weapFireType_t : std::int32_t
{                                       // ...
    WEAPON_FIRETYPE_FULLAUTO = 0x0,
    WEAPON_FIRETYPE_SINGLESHOT = 0x1,
    WEAPON_FIRETYPE_BURSTFIRE2 = 0x2,
    WEAPON_FIRETYPE_BURSTFIRE3 = 0x3,
    WEAPON_FIRETYPE_BURSTFIRE4 = 0x4,
    WEAPON_FIRETYPECOUNT = 0x5,
};

enum weapStance_t : std::int32_t
{                                       // ...
    WEAPSTANCE_STAND = 0x0,
    WEAPSTANCE_DUCK = 0x1,
    WEAPSTANCE_PRONE = 0x2,
    WEAPSTANCE_NUM = 0x3,
};

enum activeReticleType_t : std::int32_t
{                                       // ...
    VEH_ACTIVE_RETICLE_NONE = 0x0,
    VEH_ACTIVE_RETICLE_PIP_ON_A_STICK = 0x1,
    VEH_ACTIVE_RETICLE_BOUNCING_DIAMOND = 0x2,
    VEH_ACTIVE_RETICLE_COUNT = 0x3,
};

enum weaponIconRatioType_t : std::int32_t
{                                       // ...
    WEAPON_ICON_RATIO_1TO1 = 0x0,
    WEAPON_ICON_RATIO_2TO1 = 0x1,
    WEAPON_ICON_RATIO_4TO1 = 0x2,
    WEAPON_ICON_RATIO_COUNT = 0x3,
};

enum ammoCounterClipType_t : std::int32_t
{                                       // ...
    AMMO_COUNTER_CLIP_NONE = 0x0,
    AMMO_COUNTER_CLIP_MAGAZINE = 0x1,
    AMMO_COUNTER_CLIP_SHORTMAGAZINE = 0x2,
    AMMO_COUNTER_CLIP_SHOTGUN = 0x3,
    AMMO_COUNTER_CLIP_ROCKET = 0x4,
    AMMO_COUNTER_CLIP_BELTFED = 0x5,
    AMMO_COUNTER_CLIP_ALTWEAPON = 0x6,
    AMMO_COUNTER_CLIP_COUNT = 0x7,
};

enum weapOverlayReticle_t : std::int32_t
{                                       // ...
    WEAPOVERLAYRETICLE_NONE = 0x0,
    WEAPOVERLAYRETICLE_CROSSHAIR = 0x1,
    WEAPOVERLAYRETICLE_NUM = 0x2,
};

enum WeapOverlayInteface_t : std::int32_t
{                                       // ...
    WEAPOVERLAYINTERFACE_NONE = 0x0,
    WEAPOVERLAYINTERFACE_JAVELIN = 0x1,
    WEAPOVERLAYINTERFACE_TURRETSCOPE = 0x2,
    WEAPOVERLAYINTERFACECOUNT = 0x3,
};

enum weapProjExposion_t : std::int32_t
{                                       // ...
    WEAPPROJEXP_GRENADE = 0x0,
    WEAPPROJEXP_ROCKET = 0x1,
    WEAPPROJEXP_FLASHBANG = 0x2,
    WEAPPROJEXP_NONE = 0x3,
    WEAPPROJEXP_DUD = 0x4,
    WEAPPROJEXP_SMOKE = 0x5,
    WEAPPROJEXP_HEAVY = 0x6,
    WEAPPROJEXP_NUM = 0x7,
};

enum WeapStickinessType : std::int32_t
{                                       // ...
    WEAPSTICKINESS_NONE = 0x0,
    WEAPSTICKINESS_ALL = 0x1,
    WEAPSTICKINESS_GROUND = 0x2,
    WEAPSTICKINESS_GROUND_WITH_YAW = 0x3,
    WEAPSTICKINESS_COUNT = 0x4,
};

enum guidedMissileType_t : std::int32_t
{                                       // ...
    MISSILE_GUIDANCE_NONE = 0x0,
    MISSILE_GUIDANCE_SIDEWINDER = 0x1,
    MISSILE_GUIDANCE_HELLFIRE = 0x2,
    MISSILE_GUIDANCE_JAVELIN = 0x3,
    MISSILE_GUIDANCE_COUNT = 0x4,
};

enum OffhandClass : std::int32_t
{                                       // ...
    OFFHAND_CLASS_NONE = 0x0,
    OFFHAND_CLASS_FRAG_GRENADE = 0x1,
    OFFHAND_CLASS_SMOKE_GRENADE = 0x2,
    OFFHAND_CLASS_FLASH_GRENADE = 0x3,
    OFFHAND_CLASS_COUNT = 0x4,
};

enum WeapAccuracyType : std::int32_t
{
    WEAP_ACCURACY_AI_VS_AI = 0x0,
    WEAP_ACCURACY_AI_VS_PLAYER = 0x1,
    WEAP_ACCURACY_COUNT = 0x2,
};

struct WeaponDef // sizeof=0x878
{                                       // ...
    const char* szInternalName;
    const char* szDisplayName;
    const char* szOverlayName;
    XModel* gunXModel[16];
    XModel* handXModel;
    const char* szXAnims[33];
    const char* szModeName;
    std::uint16_t hideTags[8];
    std::uint16_t notetrackSoundMapKeys[16];
    std::uint16_t notetrackSoundMapValues[16];
    int playerAnimType;
    weapType_t weapType;
    weapClass_t weapClass;
    PenetrateType penetrateType;
    ImpactType impactType;
    weapInventoryType_t inventoryType;
    weapFireType_t fireType;
    OffhandClass offhandClass;
    weapStance_t stance;
    const FxEffectDef* viewFlashEffect;
    const FxEffectDef* worldFlashEffect;
    snd_alias_list_t* pickupSound;
    snd_alias_list_t* pickupSoundPlayer;
    snd_alias_list_t* ammoPickupSound;
    snd_alias_list_t* ammoPickupSoundPlayer;
    snd_alias_list_t* projectileSound;
    snd_alias_list_t* pullbackSound;
    snd_alias_list_t* pullbackSoundPlayer;
    snd_alias_list_t* fireSound;
    snd_alias_list_t* fireSoundPlayer;
    snd_alias_list_t* fireLoopSound;
    snd_alias_list_t* fireLoopSoundPlayer;
    snd_alias_list_t* fireStopSound;
    snd_alias_list_t* fireStopSoundPlayer;
    snd_alias_list_t* fireLastSound;
    snd_alias_list_t* fireLastSoundPlayer;
    snd_alias_list_t* emptyFireSound;
    snd_alias_list_t* emptyFireSoundPlayer;
    snd_alias_list_t* meleeSwipeSound;
    snd_alias_list_t* meleeSwipeSoundPlayer;
    snd_alias_list_t* meleeHitSound;
    snd_alias_list_t* meleeMissSound;
    snd_alias_list_t* rechamberSound;
    snd_alias_list_t* rechamberSoundPlayer;
    snd_alias_list_t* reloadSound;
    snd_alias_list_t* reloadSoundPlayer;
    snd_alias_list_t* reloadEmptySound;
    snd_alias_list_t* reloadEmptySoundPlayer;
    snd_alias_list_t* reloadStartSound;
    snd_alias_list_t* reloadStartSoundPlayer;
    snd_alias_list_t* reloadEndSound;
    snd_alias_list_t* reloadEndSoundPlayer;
    snd_alias_list_t* detonateSound;
    snd_alias_list_t* detonateSoundPlayer;
    snd_alias_list_t* nightVisionWearSound;
    snd_alias_list_t* nightVisionWearSoundPlayer;
    snd_alias_list_t* nightVisionRemoveSound;
    snd_alias_list_t* nightVisionRemoveSoundPlayer;
    snd_alias_list_t* altSwitchSound;
    snd_alias_list_t* altSwitchSoundPlayer;
    snd_alias_list_t* raiseSound;
    snd_alias_list_t* raiseSoundPlayer;
    snd_alias_list_t* firstRaiseSound;
    snd_alias_list_t* firstRaiseSoundPlayer;
    snd_alias_list_t* putawaySound;
    snd_alias_list_t* putawaySoundPlayer;
    snd_alias_list_t** bounceSound;
    const FxEffectDef* viewShellEjectEffect;
    const FxEffectDef* worldShellEjectEffect;
    const FxEffectDef* viewLastShotEjectEffect;
    const FxEffectDef* worldLastShotEjectEffect;
    Material* reticleCenter;
    Material* reticleSide;
    int iReticleCenterSize;
    int iReticleSideSize;
    int iReticleMinOfs;
    activeReticleType_t activeReticleType;
    float vStandMove[3];
    float vStandRot[3];
    float vDuckedOfs[3];
    float vDuckedMove[3];
    float vDuckedRot[3];
    float vProneOfs[3];
    float vProneMove[3];
    float vProneRot[3];
    float fPosMoveRate;
    float fPosProneMoveRate;
    float fStandMoveMinSpeed;
    float fDuckedMoveMinSpeed;
    float fProneMoveMinSpeed;
    float fPosRotRate;
    float fPosProneRotRate;
    float fStandRotMinSpeed;
    float fDuckedRotMinSpeed;
    float fProneRotMinSpeed;
    XModel* worldModel[16];
    XModel* worldClipModel;
    XModel* rocketModel;
    XModel* knifeModel;
    XModel* worldKnifeModel;
    Material* hudIcon;
    weaponIconRatioType_t hudIconRatio;
    Material* ammoCounterIcon;
    weaponIconRatioType_t ammoCounterIconRatio;
    ammoCounterClipType_t ammoCounterClip;
    int iStartAmmo;
    const char* szAmmoName;
    int iAmmoIndex;
    const char* szClipName;
    int iClipIndex;
    int iMaxAmmo;
    int iClipSize;
    int shotCount;
    const char* szSharedAmmoCapName;
    int iSharedAmmoCapIndex;
    int iSharedAmmoCap;
    int damage;
    int playerDamage;
    int iMeleeDamage;
    int iDamageType;
    int iFireDelay;
    int iMeleeDelay;
    int meleeChargeDelay;
    int iDetonateDelay;
    int iFireTime;
    int iRechamberTime;
    int iRechamberBoltTime;
    int iHoldFireTime;
    int iDetonateTime;
    int iMeleeTime;
    int meleeChargeTime;
    int iReloadTime;
    int reloadShowRocketTime;
    int iReloadEmptyTime;
    int iReloadAddTime;
    int iReloadStartTime;
    int iReloadStartAddTime;
    int iReloadEndTime;
    int iDropTime;
    int iRaiseTime;
    int iAltDropTime;
    int iAltRaiseTime;
    int quickDropTime;
    int quickRaiseTime;
    int iFirstRaiseTime;
    int iEmptyRaiseTime;
    int iEmptyDropTime;
    int sprintInTime;
    int sprintLoopTime;
    int sprintOutTime;
    int nightVisionWearTime;
    int nightVisionWearTimeFadeOutEnd;
    int nightVisionWearTimePowerUp;
    int nightVisionRemoveTime;
    int nightVisionRemoveTimePowerDown;
    int nightVisionRemoveTimeFadeInStart;
    int fuseTime;
    int aiFuseTime;
    int requireLockonToFire;
    int noAdsWhenMagEmpty;
    int avoidDropCleanup;
    float autoAimRange;
    float aimAssistRange;
    float aimAssistRangeAds;
    float aimPadding;
    float enemyCrosshairRange;
    int crosshairColorChange;
    float moveSpeedScale;
    float adsMoveSpeedScale;
    float sprintDurationScale;
    float fAdsZoomFov;
    float fAdsZoomInFrac;
    float fAdsZoomOutFrac;
    Material* overlayMaterial;
    Material* overlayMaterialLowRes;
    weapOverlayReticle_t overlayReticle;
    WeapOverlayInteface_t overlayInterface;
    float overlayWidth;
    float overlayHeight;
    float fAdsBobFactor;
    float fAdsViewBobMult;
    float fHipSpreadStandMin;
    float fHipSpreadDuckedMin;
    float fHipSpreadProneMin;
    float hipSpreadStandMax;
    float hipSpreadDuckedMax;
    float hipSpreadProneMax;
    float fHipSpreadDecayRate;
    float fHipSpreadFireAdd;
    float fHipSpreadTurnAdd;
    float fHipSpreadMoveAdd;
    float fHipSpreadDuckedDecay;
    float fHipSpreadProneDecay;
    float fHipReticleSidePos;
    int iAdsTransInTime;
    int iAdsTransOutTime;
    float fAdsIdleAmount;
    float fHipIdleAmount;
    float adsIdleSpeed;
    float hipIdleSpeed;
    float fIdleCrouchFactor;
    float fIdleProneFactor;
    float fGunMaxPitch;
    float fGunMaxYaw;
    float swayMaxAngle;
    float swayLerpSpeed;
    float swayPitchScale;
    float swayYawScale;
    float swayHorizScale;
    float swayVertScale;
    float swayShellShockScale;
    float adsSwayMaxAngle;
    float adsSwayLerpSpeed;
    float adsSwayPitchScale;
    float adsSwayYawScale;
    float adsSwayHorizScale;
    float adsSwayVertScale;
    int bRifleBullet;
    int armorPiercing;
    int bBoltAction;
    int aimDownSight;
    int bRechamberWhileAds;
    float adsViewErrorMin;
    float adsViewErrorMax;
    int bCookOffHold;
    int bClipOnly;
    int adsFireOnly;
    int cancelAutoHolsterWhenEmpty;
    int suppressAmmoReserveDisplay;
    int enhanced;
    int laserSightDuringNightvision;
    Material* killIcon;
    weaponIconRatioType_t killIconRatio;
    int flipKillIcon;
    Material* dpadIcon;
    weaponIconRatioType_t dpadIconRatio;
    int bNoPartialReload;
    int bSegmentedReload;
    int iReloadAmmoAdd;
    int iReloadStartAdd;
    const char* szAltWeaponName;
    std::uint32_t altWeaponIndex;
    int iDropAmmoMin;
    int iDropAmmoMax;
    int blocksProne;
    int silenced;
    int iExplosionRadius;
    int iExplosionRadiusMin;
    int iExplosionInnerDamage;
    int iExplosionOuterDamage;
    float damageConeAngle;
    int iProjectileSpeed;
    int iProjectileSpeedUp;
    int iProjectileSpeedForward;
    int iProjectileActivateDist;
    float projLifetime;
    float timeToAccelerate;
    float projectileCurvature;
    XModel* projectileModel;
    weapProjExposion_t projExplosion;
    const FxEffectDef* projExplosionEffect;
    int projExplosionEffectForceNormalUp;
    const FxEffectDef* projDudEffect;
    snd_alias_list_t* projExplosionSound;
    snd_alias_list_t* projDudSound;
    int bProjImpactExplode;
    WeapStickinessType stickiness;
    int hasDetonator;
    int timedDetonation;
    int rotate;
    int holdButtonToThrow;
    int freezeMovementWhenFiring;
    float lowAmmoWarningThreshold;
    float parallelBounce[29];
    float perpendicularBounce[29];
    const FxEffectDef* projTrailEffect;
    float vProjectileColor[3];
    guidedMissileType_t guidedMissileType;
    float maxSteeringAccel;
    int projIgnitionDelay;
    const FxEffectDef* projIgnitionEffect;
    snd_alias_list_t* projIgnitionSound;
    float fAdsAimPitch;
    float fAdsCrosshairInFrac;
    float fAdsCrosshairOutFrac;
    int adsGunKickReducedKickBullets;
    float adsGunKickReducedKickPercent;
    float fAdsGunKickPitchMin;
    float fAdsGunKickPitchMax;
    float fAdsGunKickYawMin;
    float fAdsGunKickYawMax;
    float fAdsGunKickAccel;
    float fAdsGunKickSpeedMax;
    float fAdsGunKickSpeedDecay;
    float fAdsGunKickStaticDecay;
    float fAdsViewKickPitchMin;
    float fAdsViewKickPitchMax;
    float fAdsViewKickYawMin;
    float fAdsViewKickYawMax;
    float fAdsViewKickCenterSpeed;
    float fAdsViewScatterMin;
    float fAdsViewScatterMax;
    float fAdsSpread;
    int hipGunKickReducedKickBullets;
    float hipGunKickReducedKickPercent;
    float fHipGunKickPitchMin;
    float fHipGunKickPitchMax;
    float fHipGunKickYawMin;
    float fHipGunKickYawMax;
    float fHipGunKickAccel;
    float fHipGunKickSpeedMax;
    float fHipGunKickSpeedDecay;
    float fHipGunKickStaticDecay;
    float fHipViewKickPitchMin;
    float fHipViewKickPitchMax;
    float fHipViewKickYawMin;
    float fHipViewKickYawMax;
    float fHipViewKickCenterSpeed;
    float fHipViewScatterMin;
    float fHipViewScatterMax;
    float fightDist;
    float maxDist;
    const char* accuracyGraphName[WEAP_ACCURACY_COUNT];
    float (*accuracyGraphKnots[2])[WEAP_ACCURACY_COUNT];
    float (*originalAccuracyGraphKnots[2])[WEAP_ACCURACY_COUNT];
    int accuracyGraphKnotCount[WEAP_ACCURACY_COUNT];
    int originalAccuracyGraphKnotCount[WEAP_ACCURACY_COUNT];
    int iPositionReloadTransTime;
    float leftArc;
    float rightArc;
    float topArc;
    float bottomArc;
    float accuracy;
    float aiSpread;
    float playerSpread;
    float minTurnSpeed[2];
    float maxTurnSpeed[2];
    float pitchConvergenceTime;
    float yawConvergenceTime;
    float suppressTime;
    float maxRange;
    float fAnimHorRotateInc;
    float fPlayerPositionDist;
    const char* szUseHintString;
    const char* dropHintString;
    int iUseHintStringIndex;
    int dropHintStringIndex;
    float horizViewJitter;
    float vertViewJitter;
    const char* szScript;
    float fOOPosAnimLength[2];
    int minDamage;
    int minPlayerDamage;
    float fMaxDamageRange;
    float fMinDamageRange;
    float destabilizationRateTime;
    float destabilizationCurvatureMax;
    int destabilizeDistance;
    float locationDamageMultipliers[19];
    const char* fireRumble;
    const char* meleeImpactRumble;
    float adsDofStart;
    float adsDofEnd;
};
static_assert(sizeof(void *) != 4u || sizeof(WeaponDef) == 2168u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, szXAnims) == 80u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, viewFlashEffect) == 332u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, bounceSound) == 520u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, worldModel) == 700u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, overlayMaterial) == 1072u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, projectileModel) == 1412u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, accuracyGraphName) == 1900u);
static_assert(sizeof(void *) != 4u || offsetof(WeaponDef, szUseHintString) == 2012u);
